﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentModel.ComponentResourceManager = New ComponentModel.ComponentResourceManager(GetType(Form1))
        PictureBox1 = New PictureBox()
        lblDate = New Label()
        grpPizzaSize = New GroupBox()
        Label13 = New Label()
        Label12 = New Label()
        Label11 = New Label()
        rbtLarge = New RadioButton()
        rbtMedium = New RadioButton()
        rbtSmall = New RadioButton()
        grpPizzaBase = New GroupBox()
        Label15 = New Label()
        Label14 = New Label()
        rbtGlutenFree = New RadioButton()
        rbtNormal = New RadioButton()
        GroupBox3 = New GroupBox()
        Label17 = New Label()
        Label16 = New Label()
        rbtSpicyTomato = New RadioButton()
        rbtTomato = New RadioButton()
        Toppings = New GroupBox()
        Label10 = New Label()
        Label9 = New Label()
        Label8 = New Label()
        Label7 = New Label()
        Label6 = New Label()
        Label1 = New Label()
        chkBeefStrips = New CheckBox()
        chkRibs = New CheckBox()
        chkChickenStrips = New CheckBox()
        chkMushrooms = New CheckBox()
        chkPineapple = New CheckBox()
        chkHam = New CheckBox()
        grpCheeses = New GroupBox()
        chkHalloumi = New CheckBox()
        chkMozzarella = New CheckBox()
        chkFeta = New CheckBox()
        btnClear = New Button()
        btnCompute = New Button()
        lblOrderDisplay = New Label()
        Label2 = New Label()
        ListTableNumber = New ListBox()
        txtSoftDrinks = New TextBox()
        txtChips = New TextBox()
        txtTotalAmount = New TextBox()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label18 = New Label()
        Label19 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        grpPizzaSize.SuspendLayout()
        grpPizzaBase.SuspendLayout()
        GroupBox3.SuspendLayout()
        Toppings.SuspendLayout()
        grpCheeses.SuspendLayout()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(12, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(235, 108)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' lblDate
        ' 
        lblDate.AutoSize = True
        lblDate.Location = New Point(621, 12)
        lblDate.Name = "lblDate"
        lblDate.Size = New Size(0, 15)
        lblDate.TabIndex = 1
        ' 
        ' grpPizzaSize
        ' 
        grpPizzaSize.Controls.Add(Label13)
        grpPizzaSize.Controls.Add(Label12)
        grpPizzaSize.Controls.Add(Label11)
        grpPizzaSize.Controls.Add(rbtLarge)
        grpPizzaSize.Controls.Add(rbtMedium)
        grpPizzaSize.Controls.Add(rbtSmall)
        grpPizzaSize.Location = New Point(23, 126)
        grpPizzaSize.Name = "grpPizzaSize"
        grpPizzaSize.Size = New Size(175, 100)
        grpPizzaSize.TabIndex = 2
        grpPizzaSize.TabStop = False
        grpPizzaSize.Text = "Pizza Size"
        ' 
        ' Label13
        ' 
        Label13.AutoSize = True
        Label13.Location = New Point(120, 68)
        Label13.Name = "Label13"
        Label13.Size = New Size(51, 15)
        Label13.TabIndex = 5
        Label13.Text = "Add R25"
        ' 
        ' Label12
        ' 
        Label12.AutoSize = True
        Label12.Location = New Point(120, 43)
        Label12.Name = "Label12"
        Label12.Size = New Size(51, 15)
        Label12.TabIndex = 4
        Label12.Text = "Add R15"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Location = New Point(145, 21)
        Label11.Name = "Label11"
        Label11.Size = New Size(26, 15)
        Label11.TabIndex = 3
        Label11.Text = "R25"
        ' 
        ' rbtLarge
        ' 
        rbtLarge.AutoSize = True
        rbtLarge.Location = New Point(9, 68)
        rbtLarge.Name = "rbtLarge"
        rbtLarge.Size = New Size(54, 19)
        rbtLarge.TabIndex = 2
        rbtLarge.Text = "Large"
        rbtLarge.UseVisualStyleBackColor = True
        ' 
        ' rbtMedium
        ' 
        rbtMedium.AutoSize = True
        rbtMedium.Location = New Point(9, 43)
        rbtMedium.Name = "rbtMedium"
        rbtMedium.Size = New Size(70, 19)
        rbtMedium.TabIndex = 1
        rbtMedium.Text = "Medium"
        rbtMedium.UseVisualStyleBackColor = True
        ' 
        ' rbtSmall
        ' 
        rbtSmall.AutoSize = True
        rbtSmall.Checked = True
        rbtSmall.Location = New Point(9, 21)
        rbtSmall.Name = "rbtSmall"
        rbtSmall.Size = New Size(54, 19)
        rbtSmall.TabIndex = 0
        rbtSmall.TabStop = True
        rbtSmall.Text = "Small"
        rbtSmall.UseVisualStyleBackColor = True
        ' 
        ' grpPizzaBase
        ' 
        grpPizzaBase.Controls.Add(Label15)
        grpPizzaBase.Controls.Add(Label14)
        grpPizzaBase.Controls.Add(rbtGlutenFree)
        grpPizzaBase.Controls.Add(rbtNormal)
        grpPizzaBase.Location = New Point(23, 232)
        grpPizzaBase.Name = "grpPizzaBase"
        grpPizzaBase.Size = New Size(175, 80)
        grpPizzaBase.TabIndex = 3
        grpPizzaBase.TabStop = False
        grpPizzaBase.Text = "Pizza Base"
        ' 
        ' Label15
        ' 
        Label15.AutoSize = True
        Label15.Location = New Point(120, 51)
        Label15.Name = "Label15"
        Label15.Size = New Size(51, 15)
        Label15.TabIndex = 3
        Label15.Text = "Add R15"
        ' 
        ' Label14
        ' 
        Label14.AutoSize = True
        Label14.Location = New Point(145, 25)
        Label14.Name = "Label14"
        Label14.Size = New Size(26, 15)
        Label14.TabIndex = 2
        Label14.Text = "R25"
        ' 
        ' rbtGlutenFree
        ' 
        rbtGlutenFree.AutoSize = True
        rbtGlutenFree.Location = New Point(9, 50)
        rbtGlutenFree.Name = "rbtGlutenFree"
        rbtGlutenFree.Size = New Size(85, 19)
        rbtGlutenFree.TabIndex = 1
        rbtGlutenFree.Text = "Gluten Free"
        rbtGlutenFree.UseVisualStyleBackColor = True
        ' 
        ' rbtNormal
        ' 
        rbtNormal.AutoSize = True
        rbtNormal.Checked = True
        rbtNormal.Location = New Point(9, 25)
        rbtNormal.Name = "rbtNormal"
        rbtNormal.Size = New Size(65, 19)
        rbtNormal.TabIndex = 0
        rbtNormal.TabStop = True
        rbtNormal.Text = "Normal"
        rbtNormal.UseVisualStyleBackColor = True
        ' 
        ' GroupBox3
        ' 
        GroupBox3.Controls.Add(Label17)
        GroupBox3.Controls.Add(Label16)
        GroupBox3.Controls.Add(rbtSpicyTomato)
        GroupBox3.Controls.Add(rbtTomato)
        GroupBox3.Location = New Point(23, 327)
        GroupBox3.Name = "GroupBox3"
        GroupBox3.Size = New Size(175, 76)
        GroupBox3.TabIndex = 4
        GroupBox3.TabStop = False
        GroupBox3.Text = "Base Topping"
        ' 
        ' Label17
        ' 
        Label17.AutoSize = True
        Label17.Location = New Point(124, 47)
        Label17.Name = "Label17"
        Label17.Size = New Size(45, 15)
        Label17.TabIndex = 3
        Label17.Text = "Add R5"
        ' 
        ' Label16
        ' 
        Label16.AutoSize = True
        Label16.Location = New Point(143, 22)
        Label16.Name = "Label16"
        Label16.Size = New Size(26, 15)
        Label16.TabIndex = 2
        Label16.Text = "R10"
        ' 
        ' rbtSpicyTomato
        ' 
        rbtSpicyTomato.AutoSize = True
        rbtSpicyTomato.Location = New Point(9, 47)
        rbtSpicyTomato.Name = "rbtSpicyTomato"
        rbtSpicyTomato.Size = New Size(96, 19)
        rbtSpicyTomato.TabIndex = 1
        rbtSpicyTomato.Text = "Spicy Tomato"
        rbtSpicyTomato.UseVisualStyleBackColor = True
        ' 
        ' rbtTomato
        ' 
        rbtTomato.AutoSize = True
        rbtTomato.Checked = True
        rbtTomato.Location = New Point(9, 22)
        rbtTomato.Name = "rbtTomato"
        rbtTomato.Size = New Size(65, 19)
        rbtTomato.TabIndex = 0
        rbtTomato.TabStop = True
        rbtTomato.Text = "Tomato"
        rbtTomato.UseVisualStyleBackColor = True
        ' 
        ' Toppings
        ' 
        Toppings.Controls.Add(Label10)
        Toppings.Controls.Add(Label9)
        Toppings.Controls.Add(Label8)
        Toppings.Controls.Add(Label7)
        Toppings.Controls.Add(Label6)
        Toppings.Controls.Add(Label1)
        Toppings.Controls.Add(chkBeefStrips)
        Toppings.Controls.Add(chkRibs)
        Toppings.Controls.Add(chkChickenStrips)
        Toppings.Controls.Add(chkMushrooms)
        Toppings.Controls.Add(chkPineapple)
        Toppings.Controls.Add(chkHam)
        Toppings.Location = New Point(204, 126)
        Toppings.Name = "Toppings"
        Toppings.Size = New Size(170, 186)
        Toppings.TabIndex = 5
        Toppings.TabStop = False
        Toppings.Text = "Toppings"
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(116, 152)
        Label10.Name = "Label10"
        Label10.Size = New Size(51, 15)
        Label10.TabIndex = 11
        Label10.Text = "Add R25"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(116, 125)
        Label9.Name = "Label9"
        Label9.Size = New Size(51, 15)
        Label9.TabIndex = 10
        Label9.Text = "Add R25"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(116, 101)
        Label8.Name = "Label8"
        Label8.Size = New Size(51, 15)
        Label8.TabIndex = 9
        Label8.Text = "Add R25"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(116, 75)
        Label7.Name = "Label7"
        Label7.Size = New Size(51, 15)
        Label7.TabIndex = 8
        Label7.Text = "Add R10"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(116, 52)
        Label6.Name = "Label6"
        Label6.Size = New Size(51, 15)
        Label6.TabIndex = 7
        Label6.Text = "Add R15"
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(116, 30)
        Label1.Name = "Label1"
        Label1.Size = New Size(51, 15)
        Label1.TabIndex = 6
        Label1.Text = "Add R15"
        ' 
        ' chkBeefStrips
        ' 
        chkBeefStrips.AutoSize = True
        chkBeefStrips.Location = New Point(12, 148)
        chkBeefStrips.Name = "chkBeefStrips"
        chkBeefStrips.Size = New Size(81, 19)
        chkBeefStrips.TabIndex = 5
        chkBeefStrips.Text = "Beef Strips"
        chkBeefStrips.UseVisualStyleBackColor = True
        ' 
        ' chkRibs
        ' 
        chkRibs.AutoSize = True
        chkRibs.Location = New Point(12, 124)
        chkRibs.Name = "chkRibs"
        chkRibs.Size = New Size(48, 19)
        chkRibs.TabIndex = 4
        chkRibs.Text = "Ribs"
        chkRibs.UseVisualStyleBackColor = True
        ' 
        ' chkChickenStrips
        ' 
        chkChickenStrips.AutoSize = True
        chkChickenStrips.Location = New Point(12, 100)
        chkChickenStrips.Name = "chkChickenStrips"
        chkChickenStrips.Size = New Size(101, 19)
        chkChickenStrips.TabIndex = 3
        chkChickenStrips.Text = "Chicken Strips"
        chkChickenStrips.UseVisualStyleBackColor = True
        ' 
        ' chkMushrooms
        ' 
        chkMushrooms.AutoSize = True
        chkMushrooms.Location = New Point(12, 75)
        chkMushrooms.Name = "chkMushrooms"
        chkMushrooms.Size = New Size(90, 19)
        chkMushrooms.TabIndex = 2
        chkMushrooms.Text = "Mushrooms"
        chkMushrooms.UseVisualStyleBackColor = True
        ' 
        ' chkPineapple
        ' 
        chkPineapple.AutoSize = True
        chkPineapple.Location = New Point(12, 51)
        chkPineapple.Name = "chkPineapple"
        chkPineapple.Size = New Size(78, 19)
        chkPineapple.TabIndex = 1
        chkPineapple.Text = "Pineapple"
        chkPineapple.UseVisualStyleBackColor = True
        ' 
        ' chkHam
        ' 
        chkHam.AutoSize = True
        chkHam.Location = New Point(12, 26)
        chkHam.Name = "chkHam"
        chkHam.Size = New Size(52, 19)
        chkHam.TabIndex = 0
        chkHam.Text = "Ham"
        chkHam.UseVisualStyleBackColor = True
        ' 
        ' grpCheeses
        ' 
        grpCheeses.Controls.Add(chkHalloumi)
        grpCheeses.Controls.Add(chkMozzarella)
        grpCheeses.Controls.Add(chkFeta)
        grpCheeses.Location = New Point(204, 327)
        grpCheeses.Name = "grpCheeses"
        grpCheeses.Size = New Size(170, 105)
        grpCheeses.TabIndex = 6
        grpCheeses.TabStop = False
        grpCheeses.Text = "Cheeses"
        ' 
        ' chkHalloumi
        ' 
        chkHalloumi.AutoSize = True
        chkHalloumi.Location = New Point(12, 80)
        chkHalloumi.Name = "chkHalloumi"
        chkHalloumi.Size = New Size(75, 19)
        chkHalloumi.TabIndex = 2
        chkHalloumi.Text = "Halloumi"
        chkHalloumi.UseVisualStyleBackColor = True
        ' 
        ' chkMozzarella
        ' 
        chkMozzarella.AutoSize = True
        chkMozzarella.Location = New Point(12, 55)
        chkMozzarella.Name = "chkMozzarella"
        chkMozzarella.Size = New Size(82, 19)
        chkMozzarella.TabIndex = 1
        chkMozzarella.Text = "Mozzarella"
        chkMozzarella.UseVisualStyleBackColor = True
        ' 
        ' chkFeta
        ' 
        chkFeta.AutoSize = True
        chkFeta.Location = New Point(12, 30)
        chkFeta.Name = "chkFeta"
        chkFeta.Size = New Size(48, 19)
        chkFeta.TabIndex = 0
        chkFeta.Text = "Feta"
        chkFeta.UseVisualStyleBackColor = True
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(23, 409)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(175, 23)
        btnClear.TabIndex = 7
        btnClear.Text = "&Clear Order"
        btnClear.UseVisualStyleBackColor = True
        ' 
        ' btnCompute
        ' 
        btnCompute.Location = New Point(546, 246)
        btnCompute.Name = "btnCompute"
        btnCompute.Size = New Size(123, 23)
        btnCompute.TabIndex = 8
        btnCompute.Text = "Compute &Total"
        btnCompute.UseVisualStyleBackColor = True
        ' 
        ' lblOrderDisplay
        ' 
        lblOrderDisplay.BackColor = SystemColors.ButtonFace
        lblOrderDisplay.BorderStyle = BorderStyle.FixedSingle
        lblOrderDisplay.Enabled = False
        lblOrderDisplay.FlatStyle = FlatStyle.Flat
        lblOrderDisplay.Location = New Point(380, 293)
        lblOrderDisplay.Name = "lblOrderDisplay"
        lblOrderDisplay.Size = New Size(289, 139)
        lblOrderDisplay.TabIndex = 9
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(380, 126)
        Label2.Name = "Label2"
        Label2.Size = New Size(81, 15)
        Label2.TabIndex = 10
        Label2.Text = "Table &Number"
        ' 
        ' ListTableNumber
        ' 
        ListTableNumber.FormattingEnabled = True
        ListTableNumber.ItemHeight = 15
        ListTableNumber.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "Outside", "Take-a-way"})
        ListTableNumber.Location = New Point(380, 144)
        ListTableNumber.Name = "ListTableNumber"
        ListTableNumber.Size = New Size(86, 124)
        ListTableNumber.TabIndex = 11
        ' 
        ' txtSoftDrinks
        ' 
        txtSoftDrinks.BorderStyle = BorderStyle.FixedSingle
        txtSoftDrinks.Location = New Point(608, 144)
        txtSoftDrinks.Name = "txtSoftDrinks"
        txtSoftDrinks.Size = New Size(61, 23)
        txtSoftDrinks.TabIndex = 12
        txtSoftDrinks.TextAlign = HorizontalAlignment.Center
        ' 
        ' txtChips
        ' 
        txtChips.BorderStyle = BorderStyle.FixedSingle
        txtChips.Location = New Point(608, 173)
        txtChips.Name = "txtChips"
        txtChips.Size = New Size(61, 23)
        txtChips.TabIndex = 13
        txtChips.TextAlign = HorizontalAlignment.Center
        ' 
        ' txtTotalAmount
        ' 
        txtTotalAmount.BackColor = SystemColors.MenuBar
        txtTotalAmount.BorderStyle = BorderStyle.FixedSingle
        txtTotalAmount.Enabled = False
        txtTotalAmount.Location = New Point(608, 203)
        txtTotalAmount.Name = "txtTotalAmount"
        txtTotalAmount.ReadOnly = True
        txtTotalAmount.Size = New Size(61, 23)
        txtTotalAmount.TabIndex = 14
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(472, 152)
        Label3.Name = "Label3"
        Label3.Size = New Size(130, 15)
        Label3.TabIndex = 15
        Label3.Text = "Add Soft Drinks (@R20)"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(472, 175)
        Label4.Name = "Label4"
        Label4.Size = New Size(103, 15)
        Label4.TabIndex = 16
        Label4.Text = "Add Chips (@R15)"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(472, 205)
        Label5.Name = "Label5"
        Label5.Size = New Size(32, 15)
        Label5.TabIndex = 17
        Label5.Text = "Total"
        ' 
        ' Label18
        ' 
        Label18.AutoSize = True
        Label18.Location = New Point(380, 275)
        Label18.Name = "Label18"
        Label18.Size = New Size(64, 15)
        Label18.TabIndex = 18
        Label18.Text = "Your &Order"
        ' 
        ' Label19
        ' 
        Label19.AutoSize = True
        Label19.Font = New Font("Segoe UI Black", 36F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point)
        Label19.ForeColor = Color.Maroon
        Label19.Location = New Point(310, 34)
        Label19.Name = "Label19"
        Label19.Size = New Size(282, 65)
        Label19.TabIndex = 19
        Label19.Text = "Pizza Boys"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Olive
        ClientSize = New Size(695, 459)
        Controls.Add(Label19)
        Controls.Add(Label18)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(txtTotalAmount)
        Controls.Add(txtChips)
        Controls.Add(txtSoftDrinks)
        Controls.Add(ListTableNumber)
        Controls.Add(Label2)
        Controls.Add(lblOrderDisplay)
        Controls.Add(btnCompute)
        Controls.Add(btnClear)
        Controls.Add(grpCheeses)
        Controls.Add(Toppings)
        Controls.Add(GroupBox3)
        Controls.Add(grpPizzaBase)
        Controls.Add(grpPizzaSize)
        Controls.Add(lblDate)
        Controls.Add(PictureBox1)
        Name = "Form1"
        Text = "Pizza Order Application (61097004)"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        grpPizzaSize.ResumeLayout(False)
        grpPizzaSize.PerformLayout()
        grpPizzaBase.ResumeLayout(False)
        grpPizzaBase.PerformLayout()
        GroupBox3.ResumeLayout(False)
        GroupBox3.PerformLayout()
        Toppings.ResumeLayout(False)
        Toppings.PerformLayout()
        grpCheeses.ResumeLayout(False)
        grpCheeses.PerformLayout()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblDate As Label
    Friend WithEvents grpPizzaSize As GroupBox
    Friend WithEvents grpPizzaBase As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Toppings As GroupBox
    Friend WithEvents grpCheeses As GroupBox
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCompute As Button
    Friend WithEvents lblOrderDisplay As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ListTableNumber As ListBox
    Friend WithEvents txtSoftDrinks As TextBox
    Friend WithEvents txtChips As TextBox
    Friend WithEvents txtTotalAmount As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents rbtLarge As RadioButton
    Friend WithEvents rbtMedium As RadioButton
    Friend WithEvents rbtSmall As RadioButton
    Friend WithEvents rbtGlutenFree As RadioButton
    Friend WithEvents rbtNormal As RadioButton
    Friend WithEvents rbtSpicyTomato As RadioButton
    Friend WithEvents rbtTomato As RadioButton
    Friend WithEvents chkBeefStrips As CheckBox
    Friend WithEvents chkRibs As CheckBox
    Friend WithEvents chkChickenStrips As CheckBox
    Friend WithEvents chkMushrooms As CheckBox
    Friend WithEvents chkPineapple As CheckBox
    Friend WithEvents chkHam As CheckBox
    Friend WithEvents chkHalloumi As CheckBox
    Friend WithEvents chkMozzarella As CheckBox
    Friend WithEvents chkFeta As CheckBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
End Class
