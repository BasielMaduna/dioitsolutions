﻿Imports System.ComponentModel.Design
Imports System.Net.Sockets
Imports System.Reflection.Metadata.Ecma335
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms.Design

Public Class Form1

    'These are grand declaration verables of the whole application'

    Dim CheesePrice As Decimal
    Dim PizzaSize As Decimal
    Dim SmallSize As Decimal
    Dim MediumSize As Decimal
    Dim LargeSize As Decimal
    Dim PizzaSizePrice As Decimal
    Dim PizzaBasePrice As Decimal
    Dim PizzaBaseToppingPrice As Decimal
    Dim HamPrice As Decimal
    Dim SpicyTomatoPrice As Decimal
    Dim NormalBasePrice As Decimal
    Dim TotalPrice As Decimal
    Dim GlutenBasePrice As Decimal
    Dim TomatoPrice As Decimal
    Dim MushroomsPrice As Decimal
    Dim PineapplePrice As Decimal
    Dim ChickenStripsPrice As Decimal
    Dim RibsPrice As Decimal
    Dim BeefStripsPrice As Decimal
    Dim FetaPrice As Decimal
    Dim MozzarellaPrice As Decimal
    Dim HalloumiPrice As Decimal
    Dim SoftDrinkPrice As Integer = 0
    Dim ChipsPrice As Integer = 0
    Dim chips As Integer
    Dim CheeseOption1 As String
    Dim CheeseOption2 As String
    Dim CheeseOption3 As String
    Dim iChips As Integer = 15
    Dim ToppingsPrice As Decimal
    Dim Softdrinks As Integer
    Dim iSoftdrink As Integer = 20
    Const toppingsOptionsCount As Integer = 4
    Const CheeseOptionsCount = 2



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load



        'this is the date code'
        lblDate.Text = Today()


        'This is the default index selection code'
        ListTableNumber.SelectedIndex = 0

        'This is the autoselection code for initial radiobutton options'
        rbtSmall.AutoCheck = True
        rbtNormal.AutoCheck = True
        rbtTomato.AutoCheck = True

        'This is the default values of the textbox for ships and soft drinks'
        txtChips.Text = ("0").ToString()
        txtSoftDrinks.Text = ("0").ToString()

    End Sub

    Private Sub rbtSmall_CheckedChanged(sender As Object, e As EventArgs) Handles rbtSmall.CheckedChanged

        'This code autockecks the small pizza size radio button'
        If rbtSmall.AutoCheck = True Then
            SmallSize = 25
            PizzaSizePrice = SmallSize

        End If



    End Sub

    Private Sub rbtMedium_CheckedChanged(sender As Object, e As EventArgs) Handles rbtMedium.CheckedChanged

        'This code autockecks the medium pizza size radio button increments the medium size price with the
        'intial price of the small pizza'
        If rbtMedium.Checked = True Then
            MediumSize = 25 + 15
            PizzaSizePrice = MediumSize

        End If



    End Sub

    Private Sub rbtLarge_CheckedChanged(sender As Object, e As EventArgs) Handles rbtLarge.CheckedChanged

        'This code autockecks the Large pizza size radio button increments the Large size price with the
        'intial price of the small pizza'

        If rbtLarge.Checked = True Then
            LargeSize = 25 + 25
            PizzaSizePrice = LargeSize


        End If

    End Sub

    Private Sub rbtNormal_CheckedChanged(sender As Object, e As EventArgs) Handles rbtNormal.CheckedChanged

        'This code autockecks the Normal pizza Base radio button'
        If rbtNormal.AutoCheck = True Then
            NormalBasePrice = 25
            PizzaBasePrice = NormalBasePrice

        End If

    End Sub

    Private Sub rbtGlutenFree_CheckedChanged(sender As Object, e As EventArgs) Handles rbtGlutenFree.CheckedChanged

        'This code autockecks the Gluten pizza Base radio button and increments the Gluten Base price with the
        'intial price of the Normal pizza Base'

        If rbtGlutenFree.Checked = True Then
            GlutenBasePrice = 25 + 15
            PizzaBasePrice = GlutenBasePrice

        End If

    End Sub

    Private Sub rbtTomato_CheckedChanged(sender As Object, e As EventArgs) Handles rbtTomato.CheckedChanged

        'This code autockecks the Tomato pizza Base Topping radio button'
        If rbtTomato.AutoCheck = True Then
            TomatoPrice = 10
            PizzaBaseToppingPrice = TomatoPrice

        End If


    End Sub

    Private Sub rbtSpicyTomato_CheckedChanged(sender As Object, e As EventArgs) Handles rbtSpicyTomato.CheckedChanged

        'This code autockecks the SpicyTomato pizza Base Topping radio button and increments the  spicytomato Base topping price with the
        'intial price of the Tomato pizza Base Topping Price'
        If rbtSpicyTomato.Checked = True Then
            SpicyTomatoPrice = 10 + 5
            PizzaBaseToppingPrice = SpicyTomatoPrice

        End If


    End Sub

    <Obsolete>
    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click



        'This Is a Cheese Counter Formula which enables the customer to choose their cheese flavours And
        ' limits them from choosing more than 2 options, whereby a pop message pops up if more than two options are chosen 
        ' including the cheese Counter declaration verable and the IF statement'


        Dim Cheese_Counter As Integer = 0

        If chkFeta.CheckState = 1 And chkMozzarella.CheckState = 1 And chkHalloumi.CheckState = 1 Then
            chkHalloumi.Checked = 0 And chkMozzarella.Checked = 0 And chkFeta.Checked = 0
            MsgBox("Please Select Only Two Cheese Options!")
        End If

        Dim Count_Feta As Integer
        Dim Count_Mozzarella As Integer
        Dim Count_Halloumi As Integer

        'These are increment IF statements of the cheese counts'

        If chkFeta.Checked Then Count_Feta += 1

        If chkMozzarella.Checked = 1 Then Count_Mozzarella += 1

        If chkHalloumi.CheckState = 1 Then Count_Halloumi += 1



        ' This is a Topping Counter Formula which enables the customer to choose their extra pizza flavours and
        ' limits them from choosing more than 5 options, whereby a pop message pops up if more than five options are chosen 
        ' including the Topping Counter declaration verable and the IF statement'


        Dim Topping_Counter As Integer = 0

        If chkHam.CheckState = 1 And chkPineapple.CheckState = 1 And chkMushrooms.CheckState = 1 And
             chkChickenStrips.CheckState = 1 And chkRibs.CheckState = 1 And chkBeefStrips.CheckState = 1 Then

            chkBeefStrips.CheckState = 0 And chkPineapple.CheckState = 0 And chkMushrooms.CheckState = 0 And
             chkChickenStrips.CheckState = 0 And chkRibs.CheckState = 0 And chkHam.CheckState = 0

            MsgBox("Please Select Only Five Topping Options!")
        End If



        'These are Topping Count Declaration Verables'

        Dim Count_Ham As Integer
        Dim Count_Pineapple As Integer
        Dim Count_Mushrooms As Integer
        Dim Count_ChickeStrips As Integer
        Dim Count_Ribs As Integer
        Dim Count_BeefStrips As Integer


        'These are increment IF statements of the topping counts'

        If chkHam.Checked Then Count_Ham += 1
        If chkPineapple.Checked = 1 Then Count_Pineapple += 1
        If chkMushrooms.Checked = 1 Then Count_Mushrooms += 1
        If chkChickenStrips.Checked = 1 Then Count_ChickeStrips += 1
        If chkRibs.CheckState = 1 Then Count_Ribs += 1
        If chkBeefStrips.CheckState = 1 Then Count_BeefStrips += 1




        'This is the SoftDrink and Chips Formular Code'

        If Softdrinks! = 0 Then
            SoftDrinkPrice = txtSoftDrinks.Text * iSoftdrink
        End If

        If chips! = 0 Then
            ChipsPrice = txtChips.Text * iChips
        End If


        'This is the Cheese option code, Whereby when choosing an
        'option or options it will be displayed in the Grandisplay object'


        If chkFeta.Checked Then
            CheeseOption1 = "Feta"
        Else
            CheeseOption1 = " "
        End If


        If chkMozzarella.Checked Then
            CheeseOption2 = "Mozzarella"
        Else
            CheeseOption2 = " "
        End If

        If chkHalloumi.Checked Then
            CheeseOption3 = "Halloumi"
        Else
            CheeseOption3 = " "
        End If



        If txtSoftDrinks.Text = "" Then
            MsgBox("Please Insert a Valid Value")
            txtSoftDrinks.Text = vbUseDefault

        End If

        'This is the Grand Total Formular Formula' whereby the detailing of calculations is
        'done Under every checkbox of the toppings'

        txtTotalAmount.Text = PizzaSizePrice + PizzaBasePrice + PizzaBaseToppingPrice +
            ToppingsPrice + SoftDrinkPrice + ChipsPrice
        TotalPrice = txtTotalAmount.Text


        'This is the Currency coding for all costs'

        txtTotalAmount.Text = TotalPrice.ToString("C")


        'This is the Grand Display Code For the Customer Order'

        lblOrderDisplay.Text = "The Pizza Size Price" & " " & ":" & " " & PizzaSizePrice.ToString("C") & vbNewLine &
            "The Pizza Base Price" & " " & ":" & " " & PizzaBasePrice.ToString("C") & vbNewLine & "The Pizza Base Topping Price" & " " & ":" & " " & PizzaBaseToppingPrice.ToString("C") &
            vbNewLine & "The Toppings Price" & " " & ":" & " " & ToppingsPrice.ToString("C") & vbNewLine & "The Soft Drink Price" & " " & ":" & " " & SoftDrinkPrice.ToString("C") &
            vbNewLine & "The Cheeses Picked" & " " & ":" & " " & CheeseOption1 & " " & " " & " " & CheeseOption2 & " " & " " & CheeseOption3 &
        vbNewLine & "The Chips Price" & " " & ":" & " " & ChipsPrice.ToString("C") & vbNewLine & "The Assigned Order Table Option" & " " & ":" & " " & ListTableNumber.SelectedItem().ToString() & vbNewLine &
            "Total Amount Payable By Customer" & " " & ":" & " " & TotalPrice.ToString("C")


    End Sub

    Private Sub chkHam_CheckedChanged(sender As Object, e As EventArgs) Handles chkHam.CheckedChanged

        'This code is specifically coded for the Ham Checkbox and as it is selected it gets incremented with
        'toppings price and when diselected it decrements the toppings price'

        If chkHam.Checked = True Then
            HamPrice = 15
            ToppingsPrice = HamPrice + ToppingsPrice
        Else
            ToppingsPrice = ToppingsPrice - HamPrice


        End If

    End Sub

    Private Sub chkPineapple_CheckedChanged(sender As Object, e As EventArgs) Handles chkPineapple.CheckedChanged

        'This code is specifically coded for the Pineapple Checkbox and as it is selected it gets incremented with
        'toppings price and when diselected it decrements the toppings price'

        If chkPineapple.Checked = True Then
            PineapplePrice = 15
            ToppingsPrice = PineapplePrice + ToppingsPrice
        Else
            ToppingsPrice = ToppingsPrice - PineapplePrice

        End If


    End Sub

    Private Sub chkMushrooms_CheckedChanged(sender As Object, e As EventArgs) Handles chkMushrooms.CheckedChanged

        'This code is specifically coded for the Mushrooms Checkbox and as it is selected it gets incremented with
        'toppings price and when diselected it decrements the toppings price'

        If chkMushrooms.Checked = True Then
            MushroomsPrice = 10
            ToppingsPrice = MushroomsPrice + ToppingsPrice
        Else
            ToppingsPrice = ToppingsPrice - MushroomsPrice


        End If


    End Sub

    Private Sub chkChickenStrips_CheckedChanged(sender As Object, e As EventArgs) Handles chkChickenStrips.CheckedChanged

        'This code is specifically coded for the Chicken Strips Checkbox and as it is selected it gets incremented with
        'toppings price and when diselected it decrements the toppings price'

        If chkChickenStrips.Checked = True Then
            ChickenStripsPrice = 25
            ToppingsPrice = ChickenStripsPrice + ToppingsPrice
        Else
            ToppingsPrice = ToppingsPrice - ChickenStripsPrice

        End If


    End Sub

    Private Sub chkRibs_CheckedChanged(sender As Object, e As EventArgs) Handles chkRibs.CheckedChanged

        'This code is specifically coded for the Ribs Checkbox and as it is selected it gets incremented with
        'toppings price and when diselected it decrements the toppings price'

        If chkRibs.Checked = True Then
            RibsPrice = 25
            ToppingsPrice = RibsPrice + ToppingsPrice
        Else

            ToppingsPrice = ToppingsPrice - RibsPrice
        End If


    End Sub

    Private Sub chkBeefStrips_CheckedChanged(sender As Object, e As EventArgs) Handles chkBeefStrips.CheckedChanged

        'This code is specifically coded for the Beef Strips Checkbox and as it is selected it gets incremented with
        'toppings price and when diselected it decrements the toppings price'

        If chkBeefStrips.Checked = True Then
            BeefStripsPrice = 25
            ToppingsPrice = BeefStripsPrice + ToppingsPrice
        Else
            ToppingsPrice = ToppingsPrice - BeefStripsPrice
        End If




    End Sub



    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'This code prompts when the user clicks the clear button of the order on the app.'



        MsgBox("Are you Sure You Want To Discard Current Order", MessageBoxButtons.YesNo)




        'This code clears the pizza size radion buttons
        rbtMedium.Checked = False
            rbtLarge.Checked = False

            'This code clears the pizza base option'
            rbtGlutenFree.Checked = False

            'This code clears the pizza base option'
            rbtSpicyTomato.Checked = False

            'This code clears the pizza cheese options and unchecks them'
            chkFeta.Checked = False
            chkFeta.Enabled = True
            chkHalloumi.Checked = False
            chkHalloumi.Enabled = True
            chkMozzarella.Checked = False
            chkMozzarella.Enabled = True

            'This code clears the pizza topping options and unchecks them'
            chkHam.Checked = False
            chkPineapple.Checked = False
            chkMushrooms.Checked = False
            chkBeefStrips.Checked = False
            chkChickenStrips.Checked = False
            chkRibs.Checked = False

            'This is the default index selection code'
            ListTableNumber.SelectedIndex = 0


            'This code clears the chips,softdrinks,Total and order display'
            txtChips.Text = ("0").ToString()
            txtSoftDrinks.Text = ("0").ToString()
            txtTotalAmount.Text = ""
            lblOrderDisplay.Text = ""

            'This autochecks the first options of pizza size,pizza base and pizza base topping'
            rbtSmall.AutoCheck = True
            rbtNormal.AutoCheck = True
            rbtTomato.AutoCheck = True







    End Sub

    Private Sub ListTableNumber_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListTableNumber.SelectedIndexChanged

        'This is code auto select the default selection when the option take-away is chosen and auto selects
        'the list index' 
        If ListTableNumber.SelectedIndex =
                ListTableNumber.Items.Count - 1 Then
            ListTableNumber.SelectedIndex = 0
        End If
    End Sub

    Private Sub txtSoftDrinks_TextChanged(sender As Object, e As EventArgs) Handles txtSoftDrinks.TextChanged

        'This code alerts the user to populate a valid value to avoid living the field empty'
        If txtSoftDrinks.Text = "" Then
            MsgBox("Please Insert A Value")
        End If
    End Sub

    Private Sub txtChips_TextChanged(sender As Object, e As EventArgs) Handles txtChips.TextChanged

        'This code alerts the user to populate a valid value to avoid living the field empty'
        If txtChips.Text = "" Then
            MsgBox("Please Insert A Value")
        End If
    End Sub

    'CODED BY LEHLOHONOLO BASIEL MADUNA STD.61097004 ID.9204305932088'
End Class
