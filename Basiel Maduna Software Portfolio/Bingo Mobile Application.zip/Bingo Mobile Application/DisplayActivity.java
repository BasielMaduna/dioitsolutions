package com.example.a61097004bingoapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DisplayActivity extends AppCompatActivity {

    private static final String FILENAME = "bingo.txt";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        //Initializing User Interface Elements

        ListView numericCollection2 = findViewById(R.id.NumericCollection);
        Button btnNavBack2 = findViewById(R.id.btnNavBack);

        // Read the Called numerics from the file and create an ArrayAdapter to display them

        List<Integer> calledNumbers = readCalledNumbersFromFile();
        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, calledNumbers);
        numericCollection2.setAdapter(adapter);

        //Setup Nav Back button click listener
        btnNavBack2.setOnClickListener(view -> finish());
    }

    // Read the called numerics from the file and return as a list of integers
    private List<Integer> readCalledNumbersFromFile() {
        List<Integer> calledNumbers = new ArrayList<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(new File(getFilesDir(), FILENAME)));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] numbers = line.split(" ");
                for (String numStr : numbers) {
                    if (!numStr.isEmpty()) {
                        // Jump empty strings
                        calledNumbers.add(Integer.parseInt(numStr));
                    }
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return calledNumbers;
    }
}