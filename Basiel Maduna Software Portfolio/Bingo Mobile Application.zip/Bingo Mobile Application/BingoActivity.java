package com.example.a61097004bingoapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BingoActivity extends AppCompatActivity {

    private static final String FILENAME = "bingo.txt";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bingo);

        //Initializing User Interface
        ListView numericCollection = findViewById(R.id.NumericCollection);
        Button btnNavBack1 = findViewById(R.id.btnNavBack);

        // Read and Show the accumulated Numerics

        List<Integer> calledNumbers = readCalledNumbersFromFile();
        Collections.sort(calledNumbers); //Arrange the numeric in an ascending order
        //Setup ArrayAdapter to show the called numbers in the Listview

        ArrayAdapter<Integer> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, calledNumbers);
        numericCollection.setAdapter(adapter);

        //Setup the "Nav Back" button click listener
        btnNavBack1.setOnClickListener(view -> {
            finish(); //Close current activity and navigate to the previous one.
        });
    }

    //Read the prompted numerics from the file and return them in a list format
    private List<Integer> readCalledNumbersFromFile() {
        List<Integer> calledNumbers = new ArrayList<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(new File(getFilesDir(), FILENAME)));
            String line;
            while ((line = reader.readLine()) != null) {
                //Separate the line into individual numbers and add to the list

                String[] numbers = line.split("");
                for (String numStr : numbers) {
                    if (!numStr.isEmpty()) {
                        calledNumbers.add(Integer.parseInt(numStr));
                    }
                }
            }
            reader.close();
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
        return calledNumbers;
    }
}