package com.example.a61097004bingoapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private static final String FILENAME = "bingo.txt";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bingo);

        //Initializing User Interface Elements

        ListView numericCollection3 = findViewById(R.id.NumericCollection);
        Button btnNavBack3 = findViewById(R.id.btnNavBack);

        // Read the Called numerics from the file and format the history
            List<String> calledNumbers = readCalledNumbersFromFile();
            List<String> formattedNumbers = formatBingoHistory(calledNumbers);
         //Setup ArrayAdapter to showcase  the formatted history in the Listview

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,formattedNumbers);
        numericCollection3.setAdapter(adapter);

        // Setup the "Nav Back" Button click listener
        btnNavBack3.setOnClickListener((View view) -> {
            finish();// Close the current activity and go back to the previous
        });

    }

   //Formatting the Bingo History with Round Numbers
    private List<String> formatBingoHistory(List<String> bingoHistory) {
        List<String> formattedHistory = new ArrayList<>();
        int roundNumber = 1;
        for (String round : bingoHistory) {
            formattedHistory.add("Round" + roundNumber + ": " + round);
            roundNumber++;
        }
        return formattedHistory;
    }

    // Read the called numbers from the file and return as a list
    private List<String> readCalledNumbersFromFile() {
        List<String> calledNumbers = new ArrayList<>();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(new File(getFilesDir(),FILENAME)));
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                 calledNumbers.add(line);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return calledNumbers;
    }
}
