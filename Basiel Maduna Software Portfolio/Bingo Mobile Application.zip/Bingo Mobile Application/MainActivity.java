package com.example.a61097004bingoapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class MainActivity extends AppCompatActivity {
    private TextView txtBingoNumber;

    private Set<Integer> generatedNumbers;
    private List<Set<Integer>> rounds;
    private final int currentRound = 0;
    private static final String FILENAME = "bingo.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initializing My User Interface Elements

        txtBingoNumber =findViewById(R.id.txtBingoNumber);
        Button btnBingo = findViewById(R.id.btnBingo);
        Button btnDisplay = findViewById(R.id.btnDisplay);
        Button btnNext = findViewById(R.id.btnNext);
        Button btnExit = findViewById(R.id.btnExit);
        Button btnHistory = findViewById(R.id.btnHistory);

        //Initializing my data Structures

        generatedNumbers = new HashSet<>();
        rounds = new ArrayList<>();

        // My Button Next Click Listener

        btnNext.setOnClickListener(view -> generateAndDisplayNumber());
        //My Button History Click Listener

        btnHistory.setOnClickListener(view -> openHistoryActivity());
        //My Button Bingo click listener
        btnBingo.setOnClickListener(view -> {
            //Show an Alerting Dialog to inform my users

            AlertDialog.Builder alertDialogBuilder = new
                    AlertDialog.Builder(MainActivity.this);
            alertDialogBuilder.setMessage("You've Reached Bingo Darling! Storing Numbers For Round 1" +(currentRound + 1));
            alertDialogBuilder.setPositiveButton("Cool", (dialogInterface, i) -> {
                saveCurrentRound();
                //Prompt this to save the current round to the file
                //Open my Bingo activity
                Intent intent = new Intent(MainActivity.this,BingoActivity.class);
                startActivity(intent);
            });
            //Produce and display the Alerting Dialog
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.show();
        });
        // My Button Display click listener
        btnDisplay.setOnClickListener(view -> {
            //Open DisplayActivity
            Intent intent = new Intent(MainActivity.this,DisplayActivity.class);
            startActivity(intent);
        });
        //My Button Exit Click listener
        btnExit.setOnClickListener(view -> finish());
    }
    //This Saves the current round to a file
    private void saveCurrentRound() {
        rounds.add(new HashSet<>(generatedNumbers));
        generatedNumbers.clear();

        try{
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File(getFilesDir(),FILENAME),true));

            for (Integer num : rounds.get(rounds.size()-1)){
                writer.write(num + " ");
            }
            writer.newLine();
            writer.close();
        }catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void openHistoryActivity() {

        Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
        startActivity(intent);
    }
      //Generate and Display
    @SuppressLint("SetTextI18n")
    private void generateAndDisplayNumber() {
        if (generatedNumbers.size()==100){
            txtBingoNumber.setText("All Numbers Have Been Used!");
            return;
        }
        int number;
        do {
            number =(int) (Math.random()*100);
        } while (generatedNumbers.contains(number));
        generatedNumbers.add(number);
        txtBingoNumber.setText(String.valueOf(number));

        //Saving the number to the current round

        if (currentRound >= rounds.size()){
            rounds.add(new HashSet<>());
        }
        rounds.get(currentRound).add(number);
    }

}