﻿Public Class Form1

   
    Private Sub NewClientToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewClientToolStripMenuItem.Click
        Dim New_Client As New Form2
        New_Client.Show()
    End Sub

    Private Sub FinanceCalculatorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FinanceCalculatorToolStripMenuItem.Click
        Dim Finance_Calc As New Form3
        Finance_Calc.Show()
    End Sub

    Private Sub DisplayPreviousQuotesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DisplayPreviousQuotesToolStripMenuItem.Click
        Dim Client_Records As New Form4
        Client_Records.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
