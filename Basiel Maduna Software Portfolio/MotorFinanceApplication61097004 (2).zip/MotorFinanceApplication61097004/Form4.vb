﻿
Imports System.IO
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form4

    Public table As New DataTable

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick
        DataGridView2.DataSource = table
    End Sub

    Private Sub BtnViewAllRecords_Click_1(sender As Object, e As EventArgs) Handles BtnViewAllRecords.Click

        Dim lines() As String
        Dim data() As String

        lines = File.ReadAllLines("Client Quote.txt")

        For i As Integer = 0 To lines.Length - 1 Step +1

            data = lines(i).ToString().Split("|")
            Dim row(data.Length - 1) As String

            For j As Integer = 0 To data.Length - 1 Step +1

                row(j) = data(j).Trim()
            Next j

            table.Rows.Add()
        Next i
        DataGridView2.DataSource = table
    End Sub
End Class