﻿Imports System.IO
Public Class Form3
    Dim table As New DataTable
    Private txtSurname As Object
    Private txtSAIDNo As Object
    Public Property StringPass As string
    Public Property DataGridView1 As Object

    Private Sub btnWriteToFile_Click(sender As Object, e As EventArgs) Handles BtnWriteToFile.Click
        Dim file As System.IO.StreamWriter



        file = My.Computer.FileSystem.OpenTextFileWriter("Client Quote.txt", True)

        file.WriteLine(lblID.Text.ToString & "|" & txtVP_Price.Text.ToString & "|" & txtDep_Amount.Text.ToString &
                       "|" & CmbPayTerm.Text.ToString & "|" & lblBalloonRate.Text.ToString & "%" & "|" & lblInterestRate.Text.ToString & "%" &
                       "|" & lblEstMonthRep.Text.ToString & "|" & lblAmtToFinance.Text.ToString & "|" & lblInterestAmount.Text.ToString)


        MessageBox.Show("Client Quote Capture!")
        file.Close()


    End Sub

    Private Sub TrackBBalloon_Scroll(sender As Object, e As EventArgs) Handles TrackBBalloon.Scroll
        lblBalloonRate.Text = Format(TrackBBalloon.Value / 1, "#")
    End Sub

    Private Sub TrackBarInterestRate_Scroll(sender As Object, e As EventArgs) Handles TrackBarInterestRate.Scroll
        lblInterestRate.Text = Format(TrackBarInterestRate.Value / 1, "#")
    End Sub

    Private Sub BtnFinanceCalc_Click(sender As Object, e As EventArgs) Handles BtnFinanceCalc.Click
        Dim VP_Price As Integer
        Dim Dep_Amount As Integer
        Dim Balloon_Rate As Integer
        Dim Interest_Rate As Double
        Dim Repay_Term As Integer
        Dim EstAmountRepay As Double
        Dim Finance_Amount As Double
        Dim Interest_Amount As Double
        Dim Balloon_Payment As Double
        VP_Price = Convert.ToInt32(txtVP_Price.Text)
        Dep_Amount = Convert.ToInt32(txtDep_Amount.Text)
        Balloon_Rate = Convert.ToInt32(lblBalloonRate.Text)
        Interest_Rate = Convert.ToDouble((lblInterestRate.Text) / 12) / 100
        Repay_Term = Convert.ToInt32(CmbPayTerm.SelectedItem)

        Finance_Amount = VP_Price - Dep_Amount
        EstAmountRepay = VP_Price * ((1 + Interest_Rate) ^ Repay_Term) * Interest_Rate / (((1 + Interest_Rate) ^ Repay_Term) - 1)
        Interest_Amount = (Repay_Term * EstAmountRepay) - VP_Price
        Balloon_Payment = (EstAmountRepay * Repay_Term) * (Balloon_Rate / 100)

        LblBalloon.Text = "You still owe balloon payment of" & " " & "R" & Balloon_Payment.ToString("N2") & " " & "Plus interest"
        lblEstMonthRep.Text = "R" & EstAmountRepay.ToString("N2")
        lblAmtToFinance.Text = "R" & Finance_Amount.ToString("N2")
        lblInterestAmount.Text = "R" & Interest_Amount.ToString("N2")



    End Sub

    Private Sub BtnClear_Click(sender As Object, e As EventArgs) Handles BtnClear.Click
        txtVP_Price.Text = "0"
        txtDep_Amount.Text = "0"
        CmbPayTerm.Text = " 0 "
        lblBalloonRate.Text = " "
        lblInterestRate.Text = " "
        lblEstMonthRep.Text = " "
        lblAmtToFinance.Text = " "
        lblInterestAmount.Text = " "
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class