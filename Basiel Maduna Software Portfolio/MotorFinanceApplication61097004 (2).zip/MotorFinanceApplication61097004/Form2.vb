﻿Imports System.Globalization
Imports System.IO
Imports System.Text.RegularExpressions

Public Class Form2


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim OBJ As New Form3
        OBJ.StringPass = lblClientID.Text
        OBJ.Hide()
        lblClientID.Text = txtSurname.Text.Substring(0, If(txtSurname.Text.Length >= 3, 3, txtSurname.TextLength)).ToUpper &
            txtSAIDNo.Text.Substring(0, If(txtSAIDNo.Text.Length >= 5, 5, txtSAIDNo.TextLength))

        'Email Address Validation'
        Dim regex As Regex = New Regex("^[^@\s]+@[^@\s]+\.[^@\s]+$")
        Dim isValid As Boolean = regex.IsMatch(txtEmail.Text.Trim)

        If Not isValid Then
            LblEmail.ForeColor = Color.Red
            MessageBox.Show("Please Enter A Valid Email Address!")
            MessageBox.Show("Client Email will Not get Recorded!")
            txtEmail.Text = ""

        Else
            LblEmail.ForeColor = Color.Black
            MessageBox.Show("Email Address Rectified!")
        End If

        'Opening and writing to text file'

        Dim fileRecorder As StreamReader

        fileRecorder = New StreamReader("C:/Users/27671/source/repos/MotorFinanceApplication61097004/bin/Debug/Client.txt")

        Dim LineRecord As String

        Do While fileRecorder.Peek() <> -1
            LineRecord = fileRecorder.ReadLine()

        Loop

        fileRecorder.Close()

        '
        'ID Number Validation'

        Dim ID_Number As String

        If (txtSAIDNo.Text.Length = 13) Then

            ID_Number = txtSAIDNo.Text
            lblDOB.ForeColor = Color.Black




            Dim fileCreator As System.IO.StreamWriter

            fileCreator = My.Computer.FileSystem.OpenTextFileWriter("Client.txt", True)

            fileCreator.WriteLine(lblClientID.Text.ToString & "|" & txtName.Text.ToString & "|" & txtSurname.Text.ToString &
                       "|" & txtSAIDNo.Text.ToString & "|" & txtPassport.Text.ToString & "|" & txtDOB.Text.ToString &
                       "|" & txtEmail.Text.ToString & "|" & txtContactNo.Text.ToString)
            fileCreator.Close()
            MessageBox.Show("Client Details Recorded!")



        ElseIf (txtSAIDNo.Text <> 13) = True Then
            lblDOB.ForeColor = Color.Red
            MessageBox.Show("Please Populate A Valid SA ID!")
            MessageBox.Show("Client Details Are Not Recorded!")
            txtSAIDNo.Text = ""
        End If

        'Calls the Finance Calculator immediately data has been successfully recorded.'
        Dim Finance_Calc As New Form3
        Finance_Calc.Show()



    End Sub

End Class