﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewClientToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FinanceCalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DisplayPreviousQuotesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackgroundImage = Global.MotorFinanceApplication61097004.My.Resources.Resources.CarFinancePicture
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(648, 24)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewClientToolStripMenuItem, Me.FinanceCalculatorToolStripMenuItem, Me.DisplayPreviousQuotesToolStripMenuItem})
        Me.NewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Gray
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'NewClientToolStripMenuItem
        '
        Me.NewClientToolStripMenuItem.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.NewClientToolStripMenuItem.Name = "NewClientToolStripMenuItem"
        Me.NewClientToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.NewClientToolStripMenuItem.Text = "New Client"
        '
        'FinanceCalculatorToolStripMenuItem
        '
        Me.FinanceCalculatorToolStripMenuItem.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.FinanceCalculatorToolStripMenuItem.Name = "FinanceCalculatorToolStripMenuItem"
        Me.FinanceCalculatorToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.FinanceCalculatorToolStripMenuItem.Text = "Finance Calculator"
        '
        'DisplayPreviousQuotesToolStripMenuItem
        '
        Me.DisplayPreviousQuotesToolStripMenuItem.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.DisplayPreviousQuotesToolStripMenuItem.Name = "DisplayPreviousQuotesToolStripMenuItem"
        Me.DisplayPreviousQuotesToolStripMenuItem.Size = New System.Drawing.Size(201, 22)
        Me.DisplayPreviousQuotesToolStripMenuItem.Text = "Display Previous Quotes"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 425)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(143, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "(c) 61097004 Mr LB Maduna"
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.MotorFinanceApplication61097004.My.Resources.Resources.CarFinancePicture
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(648, 460)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 425)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(140, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "(c)61097004 Mr LB Maduna"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GrayText
        Me.BackgroundImage = Global.MotorFinanceApplication61097004.My.Resources.Resources.CarFinancePicture1
        Me.ClientSize = New System.Drawing.Size(648, 484)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Motor Finance Application"
        Me.TransparencyKey = System.Drawing.Color.Gray
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewClientToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FinanceCalculatorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DisplayPreviousQuotesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
End Class
