﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.BtnViewAllRecords = New System.Windows.Forms.Button()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Client_ID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VP_Price = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Dep_Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Repaymet_Term = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Balloon_Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Interest_Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Interest_Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Balloon_Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EstMonthlyAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FinanceAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox2
        '
        Me.PictureBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox2.Image = Global.MotorFinanceApplication61097004.My.Resources.Resources.CarFinancePicture
        Me.PictureBox2.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(804, 543)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'BtnViewAllRecords
        '
        Me.BtnViewAllRecords.BackColor = System.Drawing.SystemColors.GrayText
        Me.BtnViewAllRecords.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnViewAllRecords.Location = New System.Drawing.Point(30, 26)
        Me.BtnViewAllRecords.Name = "BtnViewAllRecords"
        Me.BtnViewAllRecords.Size = New System.Drawing.Size(135, 23)
        Me.BtnViewAllRecords.TabIndex = 3
        Me.BtnViewAllRecords.Text = "View All Records"
        Me.BtnViewAllRecords.UseVisualStyleBackColor = False
        '
        'DataGridView2
        '
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Client_ID, Me.VP_Price, Me.Dep_Amount, Me.Repaymet_Term, Me.Balloon_Rate, Me.Interest_Rate, Me.Interest_Amount, Me.Balloon_Amount, Me.EstMonthlyAmount, Me.FinanceAmount})
        Me.DataGridView2.Location = New System.Drawing.Point(30, 76)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(738, 442)
        Me.DataGridView2.TabIndex = 2
        '
        'Client_ID
        '
        Me.Client_ID.HeaderText = "Client_ID"
        Me.Client_ID.Name = "Client_ID"
        '
        'VP_Price
        '
        Me.VP_Price.HeaderText = "VP_Price"
        Me.VP_Price.Name = "VP_Price"
        '
        'Dep_Amount
        '
        Me.Dep_Amount.HeaderText = "Dep_Amount"
        Me.Dep_Amount.Name = "Dep_Amount"
        '
        'Repaymet_Term
        '
        Me.Repaymet_Term.HeaderText = "Repaymet_Term"
        Me.Repaymet_Term.Name = "Repaymet_Term"
        '
        'Balloon_Rate
        '
        Me.Balloon_Rate.HeaderText = "Balloon_Rate"
        Me.Balloon_Rate.Name = "Balloon_Rate"
        '
        'Interest_Rate
        '
        Me.Interest_Rate.HeaderText = "Interest_Rate"
        Me.Interest_Rate.Name = "Interest_Rate"
        '
        'Interest_Amount
        '
        Me.Interest_Amount.HeaderText = "Interest_Amount"
        Me.Interest_Amount.Name = "Interest_Amount"
        '
        'Balloon_Amount
        '
        Me.Balloon_Amount.HeaderText = "Balloon_Amount"
        Me.Balloon_Amount.Name = "Balloon_Amount"
        '
        'EstMonthlyAmount
        '
        Me.EstMonthlyAmount.HeaderText = "EstMonthlyAmount"
        Me.EstMonthlyAmount.Name = "EstMonthlyAmount"
        '
        'FinanceAmount
        '
        Me.FinanceAmount.HeaderText = "FinanceAmount"
        Me.FinanceAmount.Name = "FinanceAmount"
        '
        'Form4
        '
        Me.ClientSize = New System.Drawing.Size(804, 543)
        Me.Controls.Add(Me.BtnViewAllRecords)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.PictureBox2)
        Me.Name = "Form4"
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Button1 As Button
    Friend WithEvents DataSet1BindingSource As BindingSource

    Friend WithEvents ClientIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PaymentValueDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ClientQuoteDataBindingSource As BindingSource
    Friend WithEvents ClientQuoteDataBindingSource1 As BindingSource

    Friend WithEvents Database1DataSetBindingSource As BindingSource

    Friend WithEvents DataTable1BindingSource As BindingSource
    Friend WithEvents DataTable1BindingSource1 As BindingSource
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents BtnViewAllRecords As Button
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents Client_ID As DataGridViewTextBoxColumn
    Friend WithEvents VP_Price As DataGridViewTextBoxColumn
    Friend WithEvents Dep_Amount As DataGridViewTextBoxColumn
    Friend WithEvents Repaymet_Term As DataGridViewTextBoxColumn
    Friend WithEvents Balloon_Rate As DataGridViewTextBoxColumn
    Friend WithEvents Interest_Rate As DataGridViewTextBoxColumn
    Friend WithEvents Interest_Amount As DataGridViewTextBoxColumn
    Friend WithEvents Balloon_Amount As DataGridViewTextBoxColumn
    Friend WithEvents EstMonthlyAmount As DataGridViewTextBoxColumn
    Friend WithEvents FinanceAmount As DataGridViewTextBoxColumn
End Class
