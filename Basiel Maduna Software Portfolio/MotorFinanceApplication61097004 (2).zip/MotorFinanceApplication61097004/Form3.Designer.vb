﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BtnWriteToFile = New System.Windows.Forms.Button()
        Me.BtnFinanceCalc = New System.Windows.Forms.Button()
        Me.TrackBarInterestRate = New System.Windows.Forms.TrackBar()
        Me.TrackBBalloon = New System.Windows.Forms.TrackBar()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtDep_Amount = New System.Windows.Forms.TextBox()
        Me.txtVP_Price = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblID = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblEstMonthRep = New System.Windows.Forms.Label()
        Me.lblAmtToFinance = New System.Windows.Forms.Label()
        Me.lblInterestAmount = New System.Windows.Forms.Label()
        Me.lblBalloonRate = New System.Windows.Forms.Label()
        Me.lblInterestRate = New System.Windows.Forms.Label()
        Me.CmbPayTerm = New System.Windows.Forms.ComboBox()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.LblBalloon = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBarInterestRate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBBalloon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.GrayText
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = Global.MotorFinanceApplication61097004.My.Resources.Resources.CarFinancePicture
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(512, 468)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'BtnWriteToFile
        '
        Me.BtnWriteToFile.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BtnWriteToFile.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnWriteToFile.Location = New System.Drawing.Point(347, 431)
        Me.BtnWriteToFile.Name = "BtnWriteToFile"
        Me.BtnWriteToFile.Size = New System.Drawing.Size(124, 23)
        Me.BtnWriteToFile.TabIndex = 36
        Me.BtnWriteToFile.Text = "Write To File"
        Me.BtnWriteToFile.UseVisualStyleBackColor = False
        '
        'BtnFinanceCalc
        '
        Me.BtnFinanceCalc.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.BtnFinanceCalc.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnFinanceCalc.Location = New System.Drawing.Point(396, 382)
        Me.BtnFinanceCalc.Name = "BtnFinanceCalc"
        Me.BtnFinanceCalc.Size = New System.Drawing.Size(75, 23)
        Me.BtnFinanceCalc.TabIndex = 35
        Me.BtnFinanceCalc.Text = "Calculate"
        Me.BtnFinanceCalc.UseVisualStyleBackColor = False
        '
        'TrackBarInterestRate
        '
        Me.TrackBarInterestRate.AutoSize = False
        Me.TrackBarInterestRate.BackColor = System.Drawing.SystemColors.GrayText
        Me.TrackBarInterestRate.LargeChange = 7
        Me.TrackBarInterestRate.Location = New System.Drawing.Point(71, 305)
        Me.TrackBarInterestRate.Maximum = 18
        Me.TrackBarInterestRate.Minimum = 7
        Me.TrackBarInterestRate.Name = "TrackBarInterestRate"
        Me.TrackBarInterestRate.Size = New System.Drawing.Size(165, 21)
        Me.TrackBarInterestRate.TabIndex = 34
        Me.TrackBarInterestRate.Value = 7
        '
        'TrackBBalloon
        '
        Me.TrackBBalloon.AutoSize = False
        Me.TrackBBalloon.BackColor = System.Drawing.SystemColors.GrayText
        Me.TrackBBalloon.LargeChange = 30
        Me.TrackBBalloon.Location = New System.Drawing.Point(71, 225)
        Me.TrackBBalloon.Maximum = 30
        Me.TrackBBalloon.Minimum = 1
        Me.TrackBBalloon.Name = "TrackBBalloon"
        Me.TrackBBalloon.Size = New System.Drawing.Size(154, 22)
        Me.TrackBBalloon.TabIndex = 33
        Me.TrackBBalloon.Value = 1
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label10.Location = New System.Drawing.Point(68, 271)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 13)
        Me.Label10.TabIndex = 32
        Me.Label10.Text = "Interest Rate %"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label9.Location = New System.Drawing.Point(65, 193)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(53, 13)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "Balloon %"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label8.Location = New System.Drawing.Point(344, 145)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(81, 13)
        Me.Label8.TabIndex = 30
        Me.Label8.Text = "Interest Amount"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label7.Location = New System.Drawing.Point(344, 105)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 13)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Amount To Finance"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.SystemColors.GrayText
        Me.Label6.Location = New System.Drawing.Point(344, 56)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(153, 13)
        Me.Label6.TabIndex = 28
        Me.Label6.Text = "Estimated Monthly  Repayment"
        '
        'txtDep_Amount
        '
        Me.txtDep_Amount.Location = New System.Drawing.Point(197, 85)
        Me.txtDep_Amount.Name = "txtDep_Amount"
        Me.txtDep_Amount.Size = New System.Drawing.Size(100, 20)
        Me.txtDep_Amount.TabIndex = 26
        '
        'txtVP_Price
        '
        Me.txtVP_Price.Location = New System.Drawing.Point(197, 53)
        Me.txtVP_Price.Name = "txtVP_Price"
        Me.txtVP_Price.Size = New System.Drawing.Size(100, 20)
        Me.txtVP_Price.TabIndex = 25
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Label5.Location = New System.Drawing.Point(65, 119)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(96, 13)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Pay Term (Months)"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.GrayText
        Me.Label4.Location = New System.Drawing.Point(65, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Deposit Amount"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.SystemColors.GrayText
        Me.Label3.Location = New System.Drawing.Point(65, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Vehicle Purchase Price"
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.BackColor = System.Drawing.SystemColors.GrayText
        Me.lblID.Location = New System.Drawing.Point(62, 15)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(0, 13)
        Me.lblID.TabIndex = 21
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.GrayText
        Me.Label1.Location = New System.Drawing.Point(16, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 13)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Client ID"
        '
        'lblEstMonthRep
        '
        Me.lblEstMonthRep.AutoSize = True
        Me.lblEstMonthRep.Location = New System.Drawing.Point(347, 73)
        Me.lblEstMonthRep.Name = "lblEstMonthRep"
        Me.lblEstMonthRep.Size = New System.Drawing.Size(0, 13)
        Me.lblEstMonthRep.TabIndex = 37
        '
        'lblAmtToFinance
        '
        Me.lblAmtToFinance.AutoSize = True
        Me.lblAmtToFinance.Location = New System.Drawing.Point(347, 122)
        Me.lblAmtToFinance.Name = "lblAmtToFinance"
        Me.lblAmtToFinance.Size = New System.Drawing.Size(0, 13)
        Me.lblAmtToFinance.TabIndex = 38
        '
        'lblInterestAmount
        '
        Me.lblInterestAmount.AutoSize = True
        Me.lblInterestAmount.Location = New System.Drawing.Point(344, 168)
        Me.lblInterestAmount.Name = "lblInterestAmount"
        Me.lblInterestAmount.Size = New System.Drawing.Size(0, 13)
        Me.lblInterestAmount.TabIndex = 39
        '
        'lblBalloonRate
        '
        Me.lblBalloonRate.AutoSize = True
        Me.lblBalloonRate.Location = New System.Drawing.Point(137, 193)
        Me.lblBalloonRate.Name = "lblBalloonRate"
        Me.lblBalloonRate.Size = New System.Drawing.Size(0, 13)
        Me.lblBalloonRate.TabIndex = 40
        '
        'lblInterestRate
        '
        Me.lblInterestRate.AutoSize = True
        Me.lblInterestRate.Location = New System.Drawing.Point(165, 271)
        Me.lblInterestRate.Name = "lblInterestRate"
        Me.lblInterestRate.Size = New System.Drawing.Size(0, 13)
        Me.lblInterestRate.TabIndex = 41
        '
        'CmbPayTerm
        '
        Me.CmbPayTerm.FormattingEnabled = True
        Me.CmbPayTerm.Items.AddRange(New Object() {"12", "24", "36", "48", "60", "72", "84", "96"})
        Me.CmbPayTerm.Location = New System.Drawing.Point(197, 116)
        Me.CmbPayTerm.Name = "CmbPayTerm"
        Me.CmbPayTerm.Size = New System.Drawing.Size(100, 21)
        Me.CmbPayTerm.TabIndex = 43
        '
        'BtnClear
        '
        Me.BtnClear.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.BtnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.BtnClear.Location = New System.Drawing.Point(19, 433)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.Size = New System.Drawing.Size(100, 23)
        Me.BtnClear.TabIndex = 44
        Me.BtnClear.Text = "&Clear"
        Me.BtnClear.UseVisualStyleBackColor = False
        '
        'LblBalloon
        '
        Me.LblBalloon.AutoSize = True
        Me.LblBalloon.Location = New System.Drawing.Point(74, 386)
        Me.LblBalloon.Name = "LblBalloon"
        Me.LblBalloon.Size = New System.Drawing.Size(0, 13)
        Me.LblBalloon.TabIndex = 45
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.MotorFinanceApplication61097004.My.Resources.Resources.CarFinancePicture
        Me.ClientSize = New System.Drawing.Size(512, 468)
        Me.Controls.Add(Me.LblBalloon)
        Me.Controls.Add(Me.BtnClear)
        Me.Controls.Add(Me.CmbPayTerm)
        Me.Controls.Add(Me.lblInterestRate)
        Me.Controls.Add(Me.lblBalloonRate)
        Me.Controls.Add(Me.lblInterestAmount)
        Me.Controls.Add(Me.lblAmtToFinance)
        Me.Controls.Add(Me.lblEstMonthRep)
        Me.Controls.Add(Me.BtnWriteToFile)
        Me.Controls.Add(Me.BtnFinanceCalc)
        Me.Controls.Add(Me.TrackBarInterestRate)
        Me.Controls.Add(Me.TrackBBalloon)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtDep_Amount)
        Me.Controls.Add(Me.txtVP_Price)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblID)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form3"
        Me.Text = "Finance Calculator"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBarInterestRate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBBalloon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents BtnWriteToFile As Button
    Friend WithEvents BtnFinanceCalc As Button
    Friend WithEvents TrackBarInterestRate As TrackBar
    Friend WithEvents TrackBBalloon As TrackBar
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtDep_Amount As TextBox
    Friend WithEvents txtVP_Price As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblID As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblEstMonthRep As Label
    Friend WithEvents lblAmtToFinance As Label
    Friend WithEvents lblInterestAmount As Label
    Friend WithEvents lblBalloonRate As Label
    Friend WithEvents lblInterestRate As Label
    Friend WithEvents CmbPayTerm As ComboBox
    Friend WithEvents BtnClear As Button
    Friend WithEvents LblBalloon As Label
End Class
