package com.example.triathalonregapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    // variables
        int CostPerPerson = 550;
        int NumberOfPeople;
        String Location;
        int TotalCost;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText people = (EditText) findViewById(R.id.txtAthleteQty);
        final Spinner Locations = (Spinner) findViewById(R.id.spnLocations);

        //Instantiate Button Class to control
        Button btnCost = (Button) findViewById(R.id.btnCost);
        btnCost.setOnClickListener(new View.OnClickListener() {

            final TextView result = ((TextView) findViewById(R.id.txtResult));

            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View view) {
                NumberOfPeople = Integer.parseInt(people.getText().toString());
                TotalCost = NumberOfPeople * CostPerPerson;
                DecimalFormat currency = new DecimalFormat("R ###,###.00");
                Location = Locations.getSelectedItem().toString();
                result.setText("Total Cost For" + "  " + Location + " is " + currency.format(TotalCost));
            }
        }); //end button cost


    } // end OnCreate

        }// end MainActivity
